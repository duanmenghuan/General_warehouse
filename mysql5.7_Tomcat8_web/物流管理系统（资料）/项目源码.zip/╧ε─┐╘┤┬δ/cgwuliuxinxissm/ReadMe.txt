访问地址：http://localhost:8080/cgwuliuxinxissm/
	管理员：admin			密码：admin
	员工：tom				密码：123
	客户：zhangsan		密码：123
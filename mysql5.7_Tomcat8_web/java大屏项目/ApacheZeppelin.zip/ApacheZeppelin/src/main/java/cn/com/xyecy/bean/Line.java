package cn.com.xyecy.bean;

public class Line {
}

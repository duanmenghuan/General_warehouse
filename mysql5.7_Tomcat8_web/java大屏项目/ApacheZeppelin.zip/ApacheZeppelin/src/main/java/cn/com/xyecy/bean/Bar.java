package cn.com.xyecy.bean;

public class Bar {
    private String name; //x轴,名称
    private int num; //y轴,数量
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public int getNum() {
        return num;
    }
    public void setNum(int num) {
        this.num = num;
    }

}
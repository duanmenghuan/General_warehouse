package cn.com.xyecy.bean;

public class Pie {
    private String time2; //x轴,名称
    private int num2; //y轴,数量

    public String getTime2() {
        return time2;
    }

    public void setTime2(String time2) {
        this.time2 = time2;
    }

    public int getNum2() {
        return num2;
    }

    public void setNum2(int num2) {
        this.num2 = num2;
    }
}
